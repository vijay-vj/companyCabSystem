package com.template.interview.model;

public class CabTaker extends Employee {

	public CabTaker() {
		super();
	}

	public CabTaker(String name, double avgRating) {
		super(name, avgRating);
	}

}
