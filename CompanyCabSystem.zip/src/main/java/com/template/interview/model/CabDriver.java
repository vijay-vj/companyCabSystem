package com.template.interview.model;

public class CabDriver extends Employee {
	//private boolean isAvailable; 
	public CabDriver() {
		super();
	}

	public CabDriver(String name, double avgRating) {
		super(name, avgRating);
 	}
	
	

}
